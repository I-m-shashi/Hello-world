package com.example.userinterface.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.userinterface.Database.dbhelper;
import com.example.userinterface.R;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity implements  View.OnClickListener{
    TextView text;
    EditText lname, lpass;
    Button lbtn;
    dbhelper mhelper;
    ArrayList<String> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        initViews();
        initListeners();
        initObjects();
    }

    private void initObjects() {
        mhelper=new dbhelper(this);
    }

    private void initListeners() {
        lbtn.setOnClickListener(this);
        text.setOnClickListener(this);
    }

    private void initViews() {
        lname = findViewById(R.id.emaillogin);
        lpass = findViewById(R.id.passwordlogin);
        lbtn = findViewById(R.id.loginbutton);
        text = findViewById(R.id.linkk);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.loginbutton:
                verifyFromSQLite();
                break;
            case R.id.linkk:
                // Navigate to RegisterActivity
                Intent intentRegister = new Intent(this, MainActivity.class);
                startActivity(intentRegister);
                break;
        }
    }

    private void verifyFromSQLite() {
        if (mhelper.checkUser(lname.getText().toString().trim()
                , lpass.getText().toString().trim())) {
           Intent accountsIntent = new Intent(this, HomeActivity.class);
             accountsIntent.putExtra("EMAIL", lname.getText().toString().trim());
//           emptyInputEditText();
         startActivity(accountsIntent);
         Toast.makeText(this,"valid Credentials",Toast.LENGTH_SHORT).show();
        } else {
            // Snack Bar to show success message that record is wrong
            Toast.makeText(this,"Invalid Credentials",Toast.LENGTH_SHORT).show();
          //  Snackbar.make(nestedScrollView, getString(R.string.error_valid_email_password), Snackbar.LENGTH_LONG).show();
        }
    }

    private void emptyInputEditText() {
        lname.setText(null);
        lpass.setText(null);
    }
}