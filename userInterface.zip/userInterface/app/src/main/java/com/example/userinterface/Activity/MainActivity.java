package com.example.userinterface.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.userinterface.Database.dbhelper;
import com.example.userinterface.Database.usermodel;
import com.example.userinterface.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "check" ;
    TextView loginlink;
    EditText rmail,rpass,rname;
    Button rbtn;
    dbhelper mhelper;
    usermodel  user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().hide();
        Log.d(TAG, "onClick:button");
        setContentView(R.layout.activity_main);

        initViews();
        initListeners();
        initObjects();
    }

    private void initObjects() {
        mhelper=new dbhelper(this);
        user=new usermodel();

    }

    private void initListeners() {
        rbtn.setOnClickListener(this);
        loginlink.setOnClickListener(this);
    }

    private void initViews() {
        loginlink=findViewById(R.id.link);
        rmail=findViewById(R.id.email);
        rpass=findViewById(R.id.password);
        rname=findViewById(R.id.username);
        rbtn=findViewById(R.id.registerbutton);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.registerbutton:
                postDataToSQLite();
                break;
            case R.id.link:
                Intent a=new Intent(this,LoginActivity.class);
                startActivity(a);
               // finish();
                break;
        }
    }

    private void postDataToSQLite() {
        if (!mhelper.checkUser(rmail.getText().toString().trim())) {
            user.setName(rname.getText().toString().trim());
            user.setEmail(rmail.getText().toString().trim());
            user.setPassword(rpass.getText().toString().trim());
            mhelper.addUser(user);
            // Snack Bar to show success message that record saved successfully
           // Snackbar.make(nestedScrollView, getString(R.string.success_message), Snackbar.LENGTH_LONG).show();
          Toast.makeText(this,"Sucuessfull registration",Toast.LENGTH_SHORT).show();
            emptyInputEditText();
        } else {
            // Snack Bar to show error message that record already exists
            //Snackbar.make(nestedScrollView, getString(R.string.error_email_exists), Snackbar.LENGTH_LONG).show();
            Toast.makeText(this,"Already registered",Toast.LENGTH_SHORT).show();
        }

    }

    private void emptyInputEditText() {
        rname.setText(null);
        rmail.setText(null);
        rpass.setText(null);
    }
}