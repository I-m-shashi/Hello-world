package com.example.userinterface.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Switch;

import com.example.userinterface.Navfragment.dashfragment;
import com.example.userinterface.Navfragment.profilefragement;
import com.example.userinterface.Navfragment.userfragment;
import com.example.userinterface.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomeActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        bottomNavigationView=findViewById(R.id.bottmnav);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        Loadfragment(new dashfragment());
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment fragment=null;
        switch (menuItem.getItemId()){
            case R.id.dashboard:
                fragment=new dashfragment();
                break;
            case R.id.User:
                fragment=new userfragment();
                break;
            case R.id.Profile:
                fragment=new profilefragement();
                break;
        }
        if(fragment!=null){
            Loadfragment(fragment);
        }
        return true;
    }
    void  Loadfragment(Fragment fragment){
        getSupportFragmentManager().beginTransaction().replace(R.id.realtivelayout,fragment).commit();
    }
}



